import sqlite3
import pandas as pd

conn = sqlite3.connect("school.db")

df = pd.read_sql("SELECT * FROM students", conn)

print("Total Rows:", len(df))
print("\nFirst 5 Rows:\n")
print(df.head())

conn.close()