from excel_importer import import_excel_to_sql

result = import_excel_to_sql(
    "abc.xlsx",
    "school.db",
    "students"
)

print(result)