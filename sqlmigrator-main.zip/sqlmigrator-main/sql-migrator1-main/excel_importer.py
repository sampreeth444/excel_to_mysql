import pandas as pd
from sqlalchemy import create_engine

def import_excel_to_sql(file_path, database, table_name):

    try:

        df = pd.read_excel(file_path)

        engine = create_engine(
            f"sqlite:///{database}"
        )

        df.to_sql(
            table_name,
            engine,
            if_exists="replace",
            index=False
        )

        return {
            "success": True,
            "table_name": table_name,
            "rows_imported": len(df)
        }

    except FileNotFoundError:

        return {
            "success": False,
            "error": "File not found"
        }

    except Exception as e:

        return {
            "success": False,
            "error": str(e)
        }