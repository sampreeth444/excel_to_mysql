import pandas as pd
from sqlalchemy import create_engine

file_name = input("Enter Excel file name: ")

df = pd.read_excel(file_name)

engine = create_engine("sqlite:///school.db")

table_name = input("Enter table name: ")

df.to_sql(
    table_name,
    engine,
    if_exists="replace",
    index=False
)

print("Import completed successfully!")
print("Rows imported:", len(df))